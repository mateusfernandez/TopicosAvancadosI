var minhabiblioteca = require("./ex002");
var http = require("http");
var minhaApp = "arquivo principal";


minhabiblioteca.temaaula = minhaApp;


http.createServer(function (req, res){
    res.writeHead (200, {'Content-Type' : 'text/html'})
    res.write("RGM:" + minhabiblioteca.conteudoaula);
    res.write("Primeiro Nome:" + minhabiblioteca.firstname + " " + "Segundo Nome: " + minhabiblioteca.lastname );

}).listen(8080);
exports.conteudoaula = "";
exports.temaaula = "";

exports.myDateTime = function(){
    return Date();
}
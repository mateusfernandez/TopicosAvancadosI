//Mateus Fernandez Silva ( 26406357)
const http = require("http");
const request = require("request");

const server = http.createServer(async (req, response) => { //gerando servidor
    if (req.url == "/") {

        request(`http://pokeapi.co/api/v2/pokemon/1/`, (err, res, body) => {

            console.log(JSON.parse(body));
            
        });

        return response.end("Servidor foi iniciado");
    }
});

server.listen("8080", () => {
    console.log("Servidor iniciado na porta 8080");
})


